﻿---
date: 2025-05-29
tags:
  - inspo
---
# talking shrimp emails
https://www.talkingshrimp.com/handpicked-emails
**Related notes**
- [[2021-05-27-subject-line-analyzer|Subject Line Analyzer]]
- [[2022-12-16-subj-line-ideas|Subj Line Ideas]]
- [[2024-02-02-welcome-email|Welcome Email]]
- [[2024-10-11-really-good-emails|Really Good Emails]]
- [[2024-11-09-samples-of-emails|Samples Of Emails]]
- [[2025-05-30-make-our-emails-look-more-like-this|Make Our Emails Look More Like This]]
- [[2025-07-14-the-1m-newsletter-system-blueprint|The 1m Newsletter System Blueprint]]
- [[2025-12-05-email-product-inspo|Email Product Inspo]]
- [[2026-01-13-5m-newsletter-copy|5m Newsletter Copy]]
- [[2026-01-13-newsletter-template-inspo|Newsletter Template Inspo]]

**Connections:** [[emails]]
