﻿---
date: 2025-09-17
tags:
  - idea
---
# BOH Timing
Total Hours (Tasks + Videos)
Tasks: 133 hours
Video Watch Time: 10 hours
Grand Total: ~143 hours of actual work
Spread Across 4 Months
4 months = ~16 weeks
143 ÷ 16 = ~9 hours/week
**Related notes**
- [[2024-09-22-boh-copy|Boh Copy]]
- [[2024-11-02-a-digital-boh-for-ceos-who-want-to-automate-their-sales-and|A Digital Boh For Ceos Who Want To Automate Their Sales And]]
- [[2024-11-20-boh-copy|Boh Copy]]
- [[2025-01-23-boh-prices|Boh Prices]]
- [[2025-01-25-boh-idea|Boh Idea]]
- [[2025-07-07-boh-upgrades|Boh Upgrades]]
- [[2026-01-23-how-to-set-up-an-automated-back-of-house-for-your-online|How To Set Up An Automated Back Of House For Your Online]]
- [[2026-02-13-back-of-house-video-rollout-collatoral|Back Of House Video Rollout Collatoral]]
- [[2026-02-28-boh-imagery|Boh Imagery]]
- [[2026-02-28-boh-imagery-2|Boh Imagery 2]]
- [[2026-03-06-the-most-important-things-to-have-in-your-boh|The Most Important Things To Have In Your Boh]]

**Connections:** [[back-of-house]] [[promos]]
